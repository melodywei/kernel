#ifndef _KERNEL_INIT_H_
#define _KERNEL_INIT_H_

#include "../lib/stdint.h"

void init_all();

#endif //!_KERNEL_INIT_H_