#ifndef _DEVICE_KEYBOARD_H_
#define _DEVICE_KEYBOARD_H_

void keyboard_init(); 

extern struct ioqueue kbd_buf;

#endif // !_DEVICE_KEYBOARD_H_