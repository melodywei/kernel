#ifndef _LIB_KERNEL_STDIOSYS_H_
#define _LIB_KERNEL_STDIOSYS_H_

#include "../stdint.h"

void printk(const char* format, ...);

#endif

